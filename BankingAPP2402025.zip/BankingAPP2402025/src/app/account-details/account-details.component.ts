import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountDetailsService } from '../services/account-details.service';
@Component({
  selector: 'app-account-details',
  standalone: true,
  imports: [],
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.scss'
})
export class AccountDetailsComponent implements OnInit {
  accountDetails: any = {};
  accountNumber: string | null = '';
  userid!:any;
  constructor(private router:Router, private accountService:AccountDetailsService) {}

  ngOnInit(): void {
    console.log('profile');
    // Get account number from localStorage
    this.userid = localStorage.getItem('userid');
    this.accountService.getAccountDetails(this.userid).subscribe(response => {
      this.accountDetails = response; 
      console.log(this.accountDetails);
    });
  }

  goBackToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}
