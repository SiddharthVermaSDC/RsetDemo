import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule, AbstractControl, ValidatorFn } from '@angular/forms';
import { Address, Bank, Company, Hair, Registration, Crypto, Coordinates } from '../models/registration.model';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { RegistartionService } from '../services/registration.service';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-registration',
  imports: [ReactiveFormsModule, ReactiveFormsModule,NgIf],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.scss'
})
export class RegistrationComponent implements OnInit {
  registerForm!: FormGroup;
  user: any;

  constructor(private fb: FormBuilder, private registration: RegistartionService,
    private http: HttpClient, private router: Router
  ) { }

  ngOnInit(): void {
    this.initlizeForm();
  }
  get formStatus() {
    return this.registerForm.controls;
  }
  initlizeForm() {
    this.registerForm = this.fb.group({
      firstName: ['', Validators.required ],
      lastName: ['', Validators.required],
      maidenName: [''],
      age: ['', [Validators.required, Validators.min(18)]],
      gender: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required,Validators.pattern('^[6-9]\\d{9}$')]],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      birthDate: ['', Validators.required],
      image: [''],
      bloodGroup: ['',Validators.required],
      height: ['', Validators.required],
      weight: ['', Validators.required],
      eyeColor: ['',Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      stateCode: ['', Validators.required],
      postalCode: ['', Validators.required],
      country: ['', Validators.required],
      department: ['', Validators.required],
      name: ['', Validators.required],
      title: ['', Validators.required],
      comaddress: ['', Validators.required],
      comcity: ['', Validators.required],
      comstate: ['', Validators.required],
      //comstateCode: ['', Validators.required],
      //compostalCode: ['', Validators.required],
      comcountry: ['', Validators.required]
    });
  }

  onSubmit() {
    this.loadData();
    this.registration.register(this.user).subscribe(
      (response) => {
        alert('Registration successful. Please Login to View Account Details.');
        this.router.navigate(['/login']);
      },
      (error) => {
        alert('Registration failed!' + error);
        //this.registerForm.reset();
      }
    );
  }

  loadData() {
    let hair = new Hair();
    hair.color = "Black";
    hair.type = "Curly";
    let bank = new Bank();
    bank.cardNumber = "1234 5678 1518";
    bank.cardExpire = "12/28";
    bank.cardType = "Credit";
    bank.currency = "INR";
    bank.iban = "iban";
    let coordinates = new Coordinates();
    coordinates.lat = 6.7878;
    coordinates.lng = 7.89999;
    let address = new Address();
    address.address = this.registerForm.controls["address"].value;
    address.city = this.registerForm.controls["city"].value;
    address.coordinates = coordinates;
    address.country = this.registerForm.controls["country"].value;
    address.postalCode = this.registerForm.controls["postalCode"].value;
    address.state = this.registerForm.controls["state"].value;
    address.stateCode = this.registerForm.controls["stateCode"].value;

    let comaddress = new Address();
    comaddress.address = this.registerForm.controls["comaddress"].value;
    comaddress.city = this.registerForm.controls["comcity"].value;
    comaddress.coordinates = coordinates;
    comaddress.country = this.registerForm.controls["comcountry"].value;
    comaddress.postalCode = this.registerForm.controls["comstate"].value;

    let crypto = new Crypto();
    crypto.coin = "";
    crypto.network = "";
    crypto.wallet = "";
    let company = new Company();
    company.address = comaddress;
    company.department = this.registerForm.controls["department"].value;
    company.name = this.registerForm.controls["name"].value;
    company.title = this.registerForm.controls["title"].value;

    this.user = new Registration();
    this.user.id = 2;
    this.user.firstName = this.registerForm.controls["firstName"].value;
    this.user.lastName = this.registerForm.controls["lastName"].value;
    this.user.maidenName = this.registerForm.controls["maidenName"].value;
    this.user.age = this.registerForm.controls["age"].value;
    this.user.gender = this.registerForm.controls["gender"].value;
    this.user.email = this.registerForm.controls["email"].value;
    this.user.phone = this.registerForm.controls["phone"].value;
    this.user.username = this.registerForm.controls["username"].value;
    this.user.password = this.registerForm.controls["password"].value;
    this.user.birthDate = this.registerForm.controls["birthDate"].value;
    this.user.image = this.registerForm.controls["image"].value;
    this.user.bloodGroup = this.registerForm.controls["bloodGroup"].value;
    this.user.height = this.registerForm.controls["height"].value;
    this.user.weight = this.registerForm.controls["weight"].value;
    this.user.eyeColor = this.registerForm.controls["eyeColor"].value;
    this.user.hair = hair;
    this.user.ip = "196.0.1.1";
    this.user.address = address;
    this.user.macAddress = "196.0.1.1";;
    this.user.university = "Hyd Central";
    this.user.bank = bank;
    this.user.company = company;
    this.user.ein = "ein";
    this.user.ssn = "ssn";
    this.user.userAgent = "ua";
    this.user.crypto = crypto;
    this.user.role = "Developer";
  }

  validateInput(event: KeyboardEvent) {
    const inputChar = event.key.charCodeAt(0);
       if (!/^[a-zA-Z\s]/.test(event.key)) {
      event.preventDefault();
    }
  }

  validateNum(event: KeyboardEvent) {
    const inputChar = event.key.charCodeAt(0);
       if (!/^[0-9]/.test(event.key)) {
      event.preventDefault();
    }
  }
}


