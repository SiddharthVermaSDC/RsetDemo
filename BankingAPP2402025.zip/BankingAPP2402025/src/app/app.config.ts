import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideStore, StoreModule } from '@ngrx/store';
import { loginReducer } from './login/state/login.reducers';
import { provideEffects } from '@ngrx/effects';
import { LoginEffects } from './login/state/login.effects';
import { HttpClient, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { AppSettingsService } from './services/app-settings.service';

const appser=new AppSettingsService(new HttpClient({}as any));

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }), 
    provideRouter(routes),
    provideHttpClient(withInterceptorsFromDi()),
    provideHttpClient(),
    {provide:AppSettingsService,useValue:appser}
    //provideStore({auth:loginReducer}),
    //provideEffects([LoginEffects])
    //importProvidersFrom(StoreModule.forRoot(loginReducer)),
    //importProvidersFrom(provideEnvironment())
  ]
};

function provideEnvironment(): import("@angular/core").ImportProvidersSource {
  throw new Error('Function not implemented.');
}


