import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { DepositComponent } from './deposit/deposit.component';
import { LogoutComponent } from './logout/logout.component';
import { authGuard } from './services/auth.guard';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    {path:'register',component:RegistrationComponent},
    {path:'dashboard',component:AccountDetailsComponent},
    {path:'deposit',component:DepositComponent,canActivate:[authGuard]},
    {path:'logout',component:LogoutComponent}
];
