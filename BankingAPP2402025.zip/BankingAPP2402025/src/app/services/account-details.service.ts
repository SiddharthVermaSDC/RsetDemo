import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppSettingsService } from './app-settings.service';

@Injectable({
  providedIn: 'root'
})
export class AccountDetailsService {
  apiURL:any;
  errorMessage:any;;
  constructor(private http: HttpClient,private appservice:AppSettingsService) {
    this.apiURL=appservice.getSettings();
  }
  
  getAccountDetails(userid: number): Observable<any> {
   
    const url = `${this.apiURL}users/${userid}`;
    console.log(url);
    return this.http.get<any>(url);
  }
}
