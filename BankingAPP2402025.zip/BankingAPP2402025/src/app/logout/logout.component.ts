import { Component } from '@angular/core';
import { LoginService } from '../login/state/login.services';

@Component({
  selector: 'app-logout',
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.scss'
})
export class LogoutComponent {
  constructor(private login:LoginService){}

  ngOnInit()
  {
    
    this.login.logout();
  }
}
