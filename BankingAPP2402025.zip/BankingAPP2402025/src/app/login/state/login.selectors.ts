import { createSelector, createFeatureSelector } from '@ngrx/store';
import { AuthState } from './login.reducers';
//import { ILoginState } from './login.state';

// Feature selector
export const selectloginState = createFeatureSelector<AuthState>('login');

// Individual selectors
export const selectUser = createSelector(
    selectloginState,
  (state: AuthState) => state.user
);

export const selectError = createSelector(
    selectloginState,
  (state: AuthState) => state.error
);

export const selectLoading = createSelector(
    selectloginState,
  (state: AuthState) => state.loading
);