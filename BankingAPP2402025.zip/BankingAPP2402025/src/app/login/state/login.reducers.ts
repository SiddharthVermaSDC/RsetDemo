import {  Action, createReducer, on, State, Store } from '@ngrx/store';
import { login, loginSuccess, loginFailure } from './login.action';
import { Observable } from 'rxjs';
//import { ILoginState } from './login.state';
//import { Action } from 'rxjs/internal/scheduler/Action';

// export const initialState: ILoginState = {
//     user: null,
//     error: null,
//     loading: false
//   };

export const initialState: AuthState = {
    user: null,
    error: null,
    loading: false
  };

  export interface AuthState {
    user: string|null;
    error: string|null;
    loading: boolean;
  }
  
  export const loginReducer = createReducer(
    initialState,
    on(login, state => ({ ...state, loading: true })),
    on(loginSuccess, (state, { user }) => ({ ...state, user, loading: false })),
    on(loginFailure, (state, { error }) => ({ ...state, error, loading: false }))
  );
  
  