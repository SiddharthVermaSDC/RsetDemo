import { Component, importProvidersFrom, OnInit } from '@angular/core';
import { provideStore, Store, StoreModule } from '@ngrx/store';
import { login } from './state/login.action';
//import { ILoginState } from './state/login.state';
import { selectError, selectLoading, selectUser } from './state/login.selectors';
import { Observable } from 'rxjs';
import { loginReducer } from './state/login.reducers';
import { LoginEffects } from './state/login.effects';
import { provideEffects } from '@ngrx/effects';
import { AppSettingsService } from '../services/app-settings.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RegistartionService } from '../services/registration.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from './state/login.services';

@Component({
  selector: 'app-login',
  imports: [ 
    ReactiveFormsModule
    //StoreModule.forRoot(loginReducer)
    //importProvidersFrom(StoreModule.forRoot(loginReducer))
    //  provideStore({ auth: loginReducer })
    //provideEffects([LoginEffects]),
  ],
  providers:[AppSettingsService,HttpClient,RegistartionService],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {
  username: any;
  password: any;
  loginForm!: FormGroup;
  //user$: Observable<any>;
  //error$: Observable<any>;
  //loading$: Observable<boolean>;

  constructor(private fb: FormBuilder,
    private router: Router,
    private loginService:LoginService
  ) {
    //this.user$ = store.select(selectUser);
    //this.error$ = store.select(selectError);
    //this.loading$ = store.select(selectLoading);
    //private store: Store<{ auth: ILoginState }>
  }

  ngOnInit(): void {
    this.initlizeForm();
  }

  initlizeForm(){
     this.loginForm = this.fb.group({
           username: ['', Validators.required],
           password: ['', Validators.required],
  })
}


  login(){
    this.username = this.loginForm.controls["username"].value;
    this.password = this.loginForm.controls["password"].value;
    this.loginService.login(this.username,this.password).subscribe(
      response=>{
        this.router.navigate(['/dashboard']);
      }
    )
    
  }
}
