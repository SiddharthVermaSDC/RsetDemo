import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-details',
  imports: [],
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.scss'
})
export class AccountDetailsComponent implements OnInit {
  accountDetails: any = null;
  accountNumber: string | null = '';

  constructor(private router:Router) {}

  ngOnInit(): void {
    // Get account number from localStorage
    this.accountNumber = localStorage.getItem('accountNumber');

    if (this.accountNumber) {
      // Fetch the profile data using AccountService
      // this.accountService.getProfile(this.accountNumber).subscribe(
      //   (data) => {
      //     this.accountDetails = data;
      //   },
      //   (error: any) => {
      //     console.error('Error fetching profile data:', error);
      //   }
      // );
    }
  }

  goBackToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}
