import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountDetailsService } from '../services/account-details.service';
@Component({
  selector: 'app-account-details',
  standalone: true,
  imports: [],
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.scss'
})
export class AccountDetailsComponent implements OnInit {
  accountDetails: any = {};
  accountNumber: string | null = '';

  constructor(private router:Router, private accountService:AccountDetailsService) {}

  ngOnInit(): void {
    // Get account number from localStorage
    //this.accountNumber = localStorage.getItem('accountNumber');
debugger;
    this.accountService.getAccountDetails(1).subscribe(response => {
      this.accountDetails = response[0]; 
      console.log(this.accountDetails);
    });
  }

  goBackToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}
