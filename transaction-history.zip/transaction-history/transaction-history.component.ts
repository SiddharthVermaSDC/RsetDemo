import { Component } from '@angular/core';
import { Transaction } from '../models/transaction.model';
import { AccountDetailsService } from '../services/account-details.service';
import { Chart, registerables } from 'chart.js';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-transaction-history',
  imports: [FormsModule,CommonModule],
  templateUrl: './transaction-history.component.html',
  styleUrl: './transaction-history.component.scss'
})
export class TransactionHistoryComponent {
  transactions: Transaction[] = [];
  filteredTransactions: Transaction[] = [];
  accountNumber: string | null = localStorage.getItem('accountNumber'); 

  // Filter criteria
  transactionType: string = '';
  startDate: Date | null = null;
  endDate: Date | null = null;

  constructor(private accountService: AccountDetailsService) {
    Chart.register(...registerables);
  }

  ngOnInit(): void {
    const accountNumber = localStorage.getItem('accountNumber');
    if (accountNumber) {
      this.accountService.getTransactions_history(accountNumber).subscribe((data) => {
        this.transactions = data.sort((a, b) => {
          return new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime();
        });
        this.filteredTransactions = [...this.transactions];

        this.createChart();
      });
    }
  }

  filterTransactions(): void {
    this.filteredTransactions = this.transactions.filter(transaction => {
      const transactionDate = new Date(transaction.transactionDate);
  
      const matchesType = this.transactionType ? transaction.transactionType === this.transactionType : true;
  
      // Ensure that the endDate is set to the end of the day (23:59:59)
      const endDateWithTime = this.endDate ? new Date(new Date(this.endDate).setHours(23, 59, 59, 999)) : null;
  
      const matchesDateRange = (!this.startDate || transactionDate >= new Date(this.startDate)) && 
                                (!endDateWithTime || transactionDate <= endDateWithTime);
                                
      return matchesType && matchesDateRange;
    });
  } 
  
  createChart(): void {
    // Step 1: Group transactions by date and calculate total amounts
    const dailyData: { [key: string]: { credited: number, debited: number } } = {};
  
    this.transactions.forEach(transaction => {
      const transactionDate = new Date(transaction.transactionDate).toLocaleDateString();
  
      if (!dailyData[transactionDate]) {
        dailyData[transactionDate] = { credited: 0, debited: 0 };
      }
  
      if (transaction.transactionType === 'Credited') {
        dailyData[transactionDate].credited += transaction.amount;
      } else if (transaction.transactionType === 'Debited') {
        dailyData[transactionDate].debited += transaction.amount;
      }
    });
  
    // Step 2: Extract dates and amounts for the chart
    const dates = Object.keys(dailyData);
    const creditedAmounts = dates.map(date => dailyData[date].credited);
    const debitedAmounts = dates.map(date => dailyData[date].debited);
  
    // Step 3: Initialize the chart with grouped data
    new Chart("transactionChart", {
      type: 'bar', // can use 'line' or any other chart type
      data: {
        labels: dates, // X-axis labels (dates)
        datasets: [
          {
            label: 'Credited Amount',
            data: creditedAmounts, // Y-axis data (credited amounts per day)
            backgroundColor: '#28a745', // Green for credited
            borderWidth: 1
          },
          {
            label: 'Debited Amount',
            data: debitedAmounts, // Y-axis data (debited amounts per day)
            backgroundColor: '#dc3545', // Red for debited
            borderWidth: 1
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Amount (₹)'
            }
          }
        },
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Daily Transaction Amounts (Credited vs Debited)'
          }
        }
      }
    });
  }  
  
}
