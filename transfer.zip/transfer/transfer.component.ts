import { Component } from '@angular/core';
import { AccountService } from '../services/account.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, } from '@angular/forms';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-transfer',
  imports: [ReactiveFormsModule,NgIf],
  standalone : true,
  templateUrl: './transfer.component.html',
  styleUrl: './transfer.component.scss'
})
export class TransferComponent {
  transferForm! : FormGroup;
  accountNumber: any;
  toAccountNumber: string = '';
  amount: number =0;
  reenterToAccountNumber: string = '';

  constructor(private accountService: AccountService,private router: Router,private fb: FormBuilder) {
    this.accountNumber = localStorage.getItem('accountNumber'); // Fetch from local storage
  }

  transfer(){
    const transferDto = {
      fromAccountNumber : this.transferForm.controls["accountnumber"].value,
      toAccountNumber : this.transferForm.controls["toAccountnumber"].value,
      amount : this.transferForm.controls["amount"].value
       };
    
    this.accountService.transfer(transferDto).subscribe(
      (response)=>{
         //alert(response);
         alert("Transfer successful.");
      },
      error=>{
          console.log(error);
      }
    )
  }

}
