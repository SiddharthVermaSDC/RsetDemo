import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { AppSettingsService } from './app/services/app-settings.service';
import { firstValueFrom } from 'rxjs';
import { HttpClient } from '@angular/common/http';

async function bootstrap() {
  const appSettingsService = new AppSettingsService(new HttpClient({} as any));
  const settings = await firstValueFrom(appSettingsService.loadSettings());
  appSettingsService.setSettings(settings);
}
bootstrapApplication(AppComponent, appConfig)
.catch((err) => console.error(err));


