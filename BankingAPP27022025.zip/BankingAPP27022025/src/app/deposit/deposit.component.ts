import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountService } from '../services/account.service';
import { catchError } from 'rxjs';

@Component({
  selector: 'app-deposit',
  imports: [ ReactiveFormsModule,NgIf],
  templateUrl: './deposit.component.html',
  styleUrl: './deposit.component.scss'
})
export class DepositComponent {
  accountnumber: any;
  amount: any;
  depositForm!: FormGroup;
  isDisabled:boolean=true;
  constructor(private fb: FormBuilder,
              private router: Router,
              private depositeService:AccountService
  ) {}

  ngOnInit(): void {
    this.initlizeForm();
    this.patchValues();

  }

  initlizeForm(){
     this.depositForm = this.fb.group({
            accountnumber: [{ value: '', disabled: true }],
            amount: ['', Validators.required],
  })
}

patchValues(){
console.log(localStorage.getItem('accountNumber'),'deposite');
  this.depositForm.patchValue({
    accountnumber:localStorage.getItem('accountNumber')
  });
}


deposit(){
    this.accountnumber = this.depositForm.controls["accountnumber"].value;
    this.amount = this.depositForm.controls["amount"].value;

    this.depositeService.deposit(this.accountnumber,this.amount).subscribe(
      (response)=>{
         //alert(response);
         alert("Deposit successful.");
      },
      error=>{
          console.log(error);
      }
    )
  }

  validateNum(event: KeyboardEvent) {
       if (!/^[0-9]/.test(event.key)) {
      event.preventDefault();
    }
  }
}
