import { Component } from '@angular/core';
import { LoginService } from '../login/state/login.services';
import { RouterLink, RouterLinkActive, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-logout',
  imports: [RouterModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.scss'
})
export class LogoutComponent {
  constructor(private login:LoginService){}

  ngOnInit()
  {
    
    this.login.logout();
  }
}
