import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AccountService } from '../services/account.service';
import { Router } from '@angular/router';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-withdraw',
  imports: [ReactiveFormsModule,NgIf],
  templateUrl: './withdraw.component.html',
  styleUrl: './withdraw.component.scss'
})
export class WithdrawComponent {
  accountnumber: any;
  amount: any;
  withdrawForm!: FormGroup;
  isDisabled:boolean=true;
  constructor(private fb: FormBuilder,
              private router: Router,
              private depositeService:AccountService
  ) {}

  ngOnInit(): void {
    this.initlizeForm();
    this.patchValues();

  }

  initlizeForm(){
     this.withdrawForm = this.fb.group({
            accountnumber: [{ value: '', disabled: true }],
            amount: ['', Validators.required],
  })
}

patchValues(){
console.log(localStorage.getItem('accountNumber'),'deposite');
  this.withdrawForm.patchValue({
    accountnumber:localStorage.getItem('accountNumber')
  });
}


deposit(){
    this.accountnumber = this.withdrawForm.controls["accountnumber"].value;
    this.amount = this.withdrawForm.controls["amount"].value;

    this.depositeService.withdraw(this.accountnumber,this.amount).subscribe(
      (response)=>{
         //alert(response);
         alert("WithDraw successful.");
      },
      error=>{
          console.log(error);
      }
    )
  }

  validateNum(event: KeyboardEvent) {
       if (!/^[0-9]/.test(event.key)) {
      event.preventDefault();
    }
  }
}
