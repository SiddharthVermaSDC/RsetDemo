import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { LoginService } from '../login/state/login.services';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-header',
  imports: [CommonModule,RouterModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent implements OnInit{
  isUserLoggedIn!: Observable<boolean>;
  message:any;
 

  constructor(private login:LoginService) { }
  time = new Observable<string>((observer) => {
    setInterval(()=>observer.next(new Date().toString()),1000);
     });

  ngOnInit() {
    // Subscribe to login status
    this.isUserLoggedIn = this.login.getLoginStatus();
    console.log(this.isUserLoggedIn,'insdieheadercomp',new Date());
    //this.isUserLoggedIn = true;
  }
}
