import { Component, effect, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterModule, RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { RegistrationComponent } from './registration/registration.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppSettingsService } from './services/app-settings.service';
import { LoginService } from './login/state/login.services';
import { StoreModule } from '@ngrx/store';
import { loginReducer } from './login/state/login.reducers';
import { EffectsModule, provideEffects } from '@ngrx/effects';
import { LoginEffects } from './login/state/login.effects';
import { Observable } from 'rxjs';
import { routes } from './app.routes';

@Component({
  standalone: true,
  selector: 'app-root',
  imports: [RouterOutlet,HeaderComponent,FooterComponent,RegistrationComponent,NgIf,
    CommonModule,HttpClientModule,RouterModule, RouterLink, RouterLinkActive, RouterOutlet
    //StoreModule.forRoot(loginReducer)
    //StoreModule.forRoot({ count: counterReducer })
   
  ],
  providers:[AppSettingsService,HttpClient,LoginService,
   
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit{
  title = 'BankingApp';
  isUserLoggedIn!: Observable<boolean>;
  constructor(
   
  ) {
    //this.user$ = store.select(selectUser);
    //this.error$ = store.select(selectError);
    //this.loading$ = store.select(selectLoading);
    //private store: Store<{ auth: ILoginState }>
  }

  ngOnInit(): void {

  }

}
