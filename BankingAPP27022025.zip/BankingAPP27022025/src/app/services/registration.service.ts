import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError  } from 'rxjs';
import { AppSettingsService } from './app-settings.service';

@Injectable({
  providedIn: 'root'
})
export class RegistartionService {
    apiURL:any;
    errorMessage:any;
    constructor(private http: HttpClient,private appservice:AppSettingsService) {
        this.apiURL=appservice.getSettings();
    }

    register(user:any):Observable<any>{
        return this.http.post(this.apiURL+"users",user).pipe(catchError(this.handleError));
    };
     
    private handleError(error: HttpErrorResponse) {
        this.errorMessage = 'Unknown error!';
        if (error.error instanceof ErrorEvent) {
          this.errorMessage = `Error: ${error.error.message}`;
        } else {
          // Server-side errors
          this.errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
         return this.errorMessage;
      }

}
