import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppSettingsService {
  private settings: any;

  constructor(private http: HttpClient) {}

  loadSettings(): Observable<any> {
    return this.http.get('\assets\app.settings.json');
  }

  getSettings(): any {
    return "http://localhost:3000/";
  }

  setSettings(settings: any): void {
    this.settings = settings;
  }
}