import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import { AppSettingsService } from './app-settings.service';
import { Transaction } from '../models/transaction.model';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  apiURL: any;
  errorMessage: any;;
  constructor(private http: HttpClient, private appservice: AppSettingsService) {
    this.apiURL = appservice.getSettings();
  }

  getbalanceDetails(userid: number): Observable<any> {
    const url = `${this.apiURL}balancedetails/${userid}`;
    return this.http.get<any>(url);
  }

  getAccountDetails(userid: number): Observable<any> {
    const url = `${this.apiURL}users/${userid}`;
    return this.http.get<any>(url);
  }

  deposit(accountNumber: string, amount: number): Observable<any> {
    const depositDto = { accountNumber, amount }; // Create DTO

    // Get JWT token from local storage
    const token = localStorage.getItem('authToken');

    // Add Authorization header with the token
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`, // Ensure token is sent
      'Content-Type': 'application/json',
    });

    return this.http.post(this.apiURL + "deposit", depositDto, { headers }).pipe(catchError(this.handleError));


  }

  withdraw(accountNumber: string, amount: number): Observable<any> {
    const withdrawDto = { accountNumber, amount }; // Create DTO

    // Get JWT token from local storage
    const token = localStorage.getItem('authToken');

    // Add Authorization header with the token
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`, // Ensure token is sent
      'Content-Type': 'application/json',
    });

    return this.http.post(this.apiURL + "withdraw", withdrawDto, { headers }).pipe(catchError(this.handleError));


  }

  getTransactions_history(accountNumber: string): Observable<any> {
    //return this.http.get<any>(`${this.apiURL}/transaction-history`);
    // Get JWT token from local storage
    const token = localStorage.getItem('authToken');
    return this.http.get<any>(this.apiURL + "transaction-history").pipe(catchError(async (err) => console.log(err)));
    // Add Authorization header with the token
    // const headers = new HttpHeaders({
    //   'Authorization': `Bearer ${token}`, // Ensure token is sent
    //   'Content-Type': 'application/json'
    // });
    // const headers = new HttpHeaders()
    //   .set('Authorization', `Bearer ${token}`)
    //   .set('Content-Type', 'application/json');
 
   // return this.http.get<Transaction[]>(`${this.apiUrl}/transactions/${accountNumber}`, { headers });
  // return this.http.get<Transaction[]>(`${this.apiUrl}/transactions/?accountNumber=${accountNumber}`);
  }

  private handleError(error: HttpErrorResponse) {
    this.errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      this.errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      this.errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return this.errorMessage;
  }

}
