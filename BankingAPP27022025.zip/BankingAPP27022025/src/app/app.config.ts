import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, RouterModule } from '@angular/router';
import { routes } from './app.routes';
import { provideStore, StoreModule } from '@ngrx/store';
import { loginReducer } from './login/state/login.reducers';
import {  provideEffects,Actions } from '@ngrx/effects';
import { LoginEffects } from './login/state/login.effects';
import { HttpClient, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { AppSettingsService } from './services/app-settings.service';
import { LoginService } from './login/state/login.services';

//const appser=new AppSettingsService(new HttpClient({}as any));

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }), 
    provideRouter(routes),
    provideHttpClient(withInterceptorsFromDi()),
    provideHttpClient(),   
    provideStore({login:loginReducer}),
    provideEffects([LoginEffects]),
  ]
};




