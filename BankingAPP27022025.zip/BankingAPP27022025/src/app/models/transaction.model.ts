export interface Transaction {
    transactionId: number;
    accountNumber: string;
    amount: number;
    transactionType: string;
    transactionDate: Date;
    description: string;
  }