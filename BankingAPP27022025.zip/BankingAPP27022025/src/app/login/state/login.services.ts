import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable, of } from 'rxjs';
import { AppSettingsService } from '../../services/app-settings.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  apiURL: any;
  errorMessage: any;
  isUserLoggedIn = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient,
    private appservice: AppSettingsService,
    private router: Router
    ) {
    const token = localStorage.getItem('authToken');
    if (token) {
      this.isUserLoggedIn.next(true);
    }
      this.apiURL = this.appservice.getSettings();
  }

  login(username: string, password: string): Observable<any> {
    return this.http.get<any>( this.apiURL + "login").pipe(
      map(response => {
        if (response && response[0].token) {
          localStorage.setItem('authToken', response[0].token);
          localStorage.setItem('accountNumber', response[0].accountNumber);
          localStorage.setItem('accountId', response[0].accountId);
          localStorage.setItem('userid', response[0].id);  
          this.isUserLoggedIn.next(true);  
          
        }
       
        return response;
      })
    );
  }

  logout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('accountNumber');
    this.isUserLoggedIn.next(false); // Set logged in state to false
    this.router.navigate(['/logout']);
  }

  //Expose the logged-in state as an observable
  getLoginStatus(): Observable<boolean> {
    console.log(this.isUserLoggedIn,'getLoginStatus()',new Date());
        return this.isUserLoggedIn.asObservable();
       
  };
}