import { Injectable } from "@angular/core";
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { defer, of } from 'rxjs';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import { LoginService } from './login.services';
import { login, loginSuccess, loginFailure } from './login.action';

@Injectable()
export class LoginEffects {
    constructor(
        private actions$: Actions,
        private loginService: LoginService
      ) {
      }
      ngOnInit() {
        // Ensure initialization is complete
      }
      login$ = createEffect(() =>
        defer(() => {
          return this.actions$.pipe(
            ofType(login),
            mergeMap(action =>
              this.loginService.login(action.username, action.password).pipe(
                map(user => loginSuccess({ user })),
                catchError(error => of(loginFailure({ error })))
              )
            )
          );
        })
      );
    }
  

