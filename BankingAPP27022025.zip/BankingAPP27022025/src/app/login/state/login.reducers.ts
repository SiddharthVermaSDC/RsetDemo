import {  createReducer, on } from '@ngrx/store';
import { login, loginSuccess, loginFailure } from './login.action';

// export const initialState: ILoginState = {
//     user: null,
//     error: null,
//     loading: false
//   };

export const initialState: AuthState = {
    user: null,
    error: null,
    loading: false
  };

  export interface AuthState {
    user: any|null;
    error: any|null;
    loading: boolean;
  }
  
  export const loginReducer = createReducer(
    initialState,
    on(login, state => ({ ...state, loading: true })),
    on(loginSuccess, (state, { user }) => ({ ...state, user, loading: false })),
    on(loginFailure, (state, { error }) => ({ ...state, error, loading: false }))
  );
  
  