import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppSettingsService } from '../services/app-settings.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RegistartionService } from '../services/registration.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from './state/login.services';
import * as loginactions from './state/login.action';
import { selectUser } from './state/login.selectors';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { AuthState } from './state/login.reducers';

@Component({
  selector: 'app-login',
  imports: [ 
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers:[AppSettingsService,HttpClient,RegistartionService],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit,OnDestroy  {
  username:any;
  password:any;
  loginForm!: FormGroup;
  user$!: Observable<any>;
  private subscription!: Subscription;
  //error$: Observable<any>;
  //loading$: Observable<boolean>;
  constructor(private fb: FormBuilder,
    private router: Router,
    private loginService:LoginService,
    private store: Store<{ auth: AuthState }>
  ) {
   
    //this.error$ = store.select(selectError);
    //this.loading$ = store.select(selectLoading);
    //private store: Store<{ auth: ILoginState }>
  }

  ngOnInit(): void {
    this.initlizeForm();
    //Store Calls
    // this.user$ = this.store.select(selectUser);
    
    // this.subscription=this.user$.subscribe(res=>{
    //   if(res){
    //     this.router.navigate(['/dashboard']);
    //   }
    // })
  }

  initlizeForm(){
     this.loginForm = this.fb.group({
           username: ['', Validators.required],
           password: ['', Validators.required],
  })
}


  login(){
    this.username = this.loginForm.controls["username"].value;
    this.password = this.loginForm.controls["password"].value;
    //this.dispatchAction(this.username,this.password);
    this.loginService.login(this.username,this.password).subscribe(
      response=>{
        this.router.navigate(['/dashboard']);
      }
    )
    
  }

  dispatchAction(username:string,password:string){
    this.store.dispatch(loginactions.login({username,password}));
  }

  ngOnDestroy() {
    // Unsubscribe to prevent memory leaks
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

}
