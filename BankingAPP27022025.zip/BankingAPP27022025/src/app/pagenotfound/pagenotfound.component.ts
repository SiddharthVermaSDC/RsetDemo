import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-pagenotfound',
  templateUrl: './pagenotfound.component.html',
  styleUrl: './pagenotfound.component.css',
  imports:[RouterModule, RouterLink, RouterLinkActive, RouterOutlet]
})
export class PagenotfoundComponent {

}
