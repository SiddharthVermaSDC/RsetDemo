import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountDetailsService } from '../services/account-details.service';

@Component({
  selector: 'app-dashboard',
  imports: [],
  standalone: true,
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent {
  accountDetails: any = {};
  accountNumber: string | null = '';
  userid!:any;
  balance: number = 138967;
  cvv : string = '***';
  constructor(private accountService:AccountDetailsService) {}

  ngOnInit(): void {
    console.log('profile');
    // Get account number from localStorage
    this.userid = localStorage.getItem('userid');
    this.accountService.getAccountDetails(this.userid).subscribe(response => {
      this.accountDetails = response; 
      console.log(this.accountDetails);
    });
  }

  // // Method to format expiry date to show MM/YY
  // formatExpiryDate(expiryDate: string | Date): string {
  //   const date = typeof expiryDate === 'string' ? new Date(expiryDate) : expiryDate;
  //   const month = date.getMonth() + 1; // Get the month (0-based index)
  //   const year = date.getFullYear().toString().slice(-2); // Get last two digits of the year
  //   return `${month.toString().padStart(2, '0')}/${year}`; // Format as MM/YY
  // }

  // // Method to format card number by adding spaces every 4 digits
  // formatCardNumber(cardNumber: string): string {
  //   return cardNumber.replace(/(.{4})/g, '$1 ').trim(); // Adds space after every 4 digits
  // }
}
