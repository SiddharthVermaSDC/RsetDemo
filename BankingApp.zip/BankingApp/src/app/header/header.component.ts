import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-header',
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  constructor() { }

  time = new Observable<string>((observer) => {
    setInterval(()=>observer.next(new Date().toString()),1000);
     });

  ngOnInit() {
    // Subscribe to login status
    //this.isUserLoggedIn = this.authService.getLoginStatus();
  }
}
