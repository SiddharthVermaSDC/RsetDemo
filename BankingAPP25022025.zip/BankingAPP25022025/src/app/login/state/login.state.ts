// export interface ILoginState {
//     user: any;
//     error: any;
//     loading: boolean;
//   }