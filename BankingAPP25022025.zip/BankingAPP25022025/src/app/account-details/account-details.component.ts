import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../services/account.service';
import { NgIf } from '@angular/common';
@Component({
  selector: 'app-account-details',
  standalone: true,
  imports: [NgIf],
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.scss'
})
export class AccountDetailsComponent implements OnInit {
  accountDetails: any = {};
  accountNumber: string | null = '';
  userid!: any;
  isDataAvailable: boolean = false;
  constructor(private router: Router, 
            private accountService: AccountService) { }

  ngOnInit(): void {
    //Get account number from localStorage
    this.userid = localStorage.getItem('userid');
    this.accountService.getAccountDetails(this.userid).subscribe(response => {
      this.accountDetails = response;
      this.isDataAvailable = true;
    });
  }

  goBackToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}
