import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { DepositComponent } from './deposit/deposit.component';
import { LogoutComponent } from './logout/logout.component';
import { authGuard } from './services/auth.guard';
import { TransferComponent } from './transfer/transfer.component';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login',
        loadComponent: () => import('../app/login/login.component').then(m => m.LoginComponent) },
    {path:'register',component:RegistrationComponent},
    {path:'dashboard',component:AccountDetailsComponent},
    {path:'deposit',component:DepositComponent,canActivate:[authGuard]},
    {path:'tansfer',component:TransferComponent,canActivate:[authGuard]},
    {path:'logout',component:LogoutComponent}
];
