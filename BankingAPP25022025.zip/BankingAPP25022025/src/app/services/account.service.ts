import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';
import { AppSettingsService } from './app-settings.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  apiURL:any;
  errorMessage:any;;
  constructor(private http: HttpClient,private appservice:AppSettingsService) {
    this.apiURL=appservice.getSettings();
  }
  
  getAccountDetails(userid: number): Observable<any> {
    const url = `${this.apiURL}users/${userid}`;
    return this.http.get<any>(url);
  }

  deposit(accountNumber: string, amount: number): Observable<any> {
    const depositDto = { accountNumber, amount }; // Create DTO
   
    // Get JWT token from local storage
    const token = localStorage.getItem('authToken');
  
    // Add Authorization header with the token
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`, // Ensure token is sent
      'Content-Type': 'application/json',
    });
  
    return this.http.post(this.apiURL+"deposit",depositDto,{headers}).pipe(catchError(this.handleError));


  }

  private handleError(error: HttpErrorResponse) {
          this.errorMessage = 'Unknown error!';
          if (error.error instanceof ErrorEvent) {
            this.errorMessage = `Error: ${error.error.message}`;
          } else {
            // Server-side errors
            this.errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
          }
           return this.errorMessage;
        }

}
