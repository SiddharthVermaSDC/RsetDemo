import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { LoginService } from '../login/state/login.services';
import { first, map } from 'rxjs';


export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const login = inject(LoginService);

  return login.isUserLoggedIn.pipe(
    first(),
    map((loginStatus: boolean)=>{
      if(!loginStatus){
        router.navigate(['login']);
        return false;
      }
      return true;
    })
  );
};
