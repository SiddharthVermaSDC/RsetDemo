export class Registration {
    id: number;
    firstName: string;
    lastName: string;
    maidenName: string;
    age: number;
    gender: string;
    email: string;
    phone: number;
    username: string;
    password: string;
    birthDate: Date;
    image: string;
    bloodGroup: string;
    height: number;
    weight: number;
    eyeColor: string;
    hair: Hair;
    ip: string;
    address: Address;
    macAddress: string;
    university: string;
    bank: Bank;
    company: Company;
    ein: string;
    ssn: string;
    userAgent: string;
    crypto: Crypto;
    role: string;
    constructor() {
        this.id = 9;
        this.firstName = "";
        this.lastName = "";
        this.maidenName = "";
        this.age = 0;
        this.gender = "";
        this.email = "";
        this.phone = 0;
        this.username = "";
        this.password = "";
        this.birthDate = new Date();
        this.image = "";
        this.bloodGroup = "";
        this.height = 0;
        this.weight = 0;
        this.eyeColor = "";
        this.hair = new Hair();
        this.ip = "";
        this.address = new Address();
        this.macAddress="";
        this.university="";
        this.bank=new Bank();
        this.company=new  Company();
        this.ein="";
        this.ssn="";
        this.userAgent="";
        this.crypto=new Crypto();
        this.role="";
    }
}
export class Hair {
    public color: string;
    public type: string;
    constructor() {
        this.color = "";
        this.type = "";
    }
}

export class Coordinates {
    public lat: number;
    public lng: number;
    constructor(

    ) {
        this.lat = 0;
        this.lng = 0;
    }
}

export class Address {
    public address: string;
    public city: string;
    public state: string;
    public stateCode: string;
    public postalCode: string;
    public coordinates: Coordinates;
    public country: string
    constructor(

    ) {
        this.address = "";
        this.city = "";
        this.state = "";
        this.stateCode = "";
        this.postalCode = "";
        this.coordinates = new Coordinates();
        this.country = "";
    }
}

export class Bank {
    public cardExpire: string;
    public cardNumber: string;
    public cardType: string;
    public currency: string;
    public iban: string;
    constructor(

    ) {
        this.cardExpire = "";
        this.cardNumber = "";
        this.cardType = "";
        this.currency = "";
        this.iban = "";
    }
}

export class Company {
    public department: string;
    public name: string;
    public title: string;
    public address: Address;
    constructor() {
        this.department = "";
        this.name = "";
        this.title = "";
        this.address = new Address();
    }
}

export class Crypto {
    public coin: string;
    public wallet: string;
    public network: string;
    constructor() {
        this.coin = "";
        this.wallet = "";
        this.network = "";
    }
}