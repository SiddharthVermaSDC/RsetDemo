import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginService } from '../login/state/login.services';

@Component({
  selector: 'app-header',
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent implements OnInit{
  isUserLoggedIn!: Observable<boolean>;
  message:any;

  constructor(private login:LoginService) { }
  time = new Observable<string>((observer) => {
    setInterval(()=>observer.next(new Date().toString()),1000);
     });

  ngOnInit() {
    // Subscribe to login status
    this.isUserLoggedIn = this.login.getLoginStatus();
  }
}
