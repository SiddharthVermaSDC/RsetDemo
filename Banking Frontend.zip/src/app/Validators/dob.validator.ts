import { AbstractControl, ValidatorFn } from '@angular/forms';

export function dateOfBirthValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    const dob = new Date(control.value); // Get the date from the control
    const today = new Date();

    // Check if the date is in the future
    if (dob > today) {
      return { 'futureDate': true }; // Return an error if the date is in the future
    }

    // Calculate age
    const age = today.getFullYear() - dob.getFullYear();
    const monthDifference = today.getMonth() - dob.getMonth();
    const isBirthdayPassed = monthDifference > 0 || (monthDifference === 0 && today.getDate() >= dob.getDate());

    // Check if the user is at least 18 years old
    if (age < 18 || (age === 18 && !isBirthdayPassed)) {
      return { 'underage': true }; // Return an error if the user is underage
    }

    return null; // No errors
  };
}
