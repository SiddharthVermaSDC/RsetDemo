import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';

export interface Transaction {
  transactionId: number;
  accountNumber: string;
  amount: number;
  transactionType: string;
  transactionDate: Date;
  description: string;
}

export interface VirtualCard {
  cardId: number;
  accountId: number;
  cardNumber: string;
  expiryDate: Date;
  cvv: string;
  cardType: string; // 'Debit' or 'Credit'
  // Optional fields if any
  creditLimit?: number; // Add this only if it applies to credit cards
}


@Injectable({
  providedIn: 'root'
})

export class AccountService {

  private apiUrl = 'https://localhost:7025'; //API URL

  constructor(private http: HttpClient) { }

  getBalance(accountNumber: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/balance/${accountNumber}`);
  }

  deposit(accountNumber: string, amount: number): Observable<any> {
    const depositDto = { accountNumber, amount }; // Create DTO
    
    // Get JWT token from local storage
    const token = localStorage.getItem('authToken');
  
    // Add Authorization header with the token
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`, // Ensure token is sent
      'Content-Type': 'application/json'
    });
  
    return this.http.post<any>(`${this.apiUrl}/deposit`, depositDto, { headers }).pipe(
      tap(response => console.log('Deposit response:', response)), // Log response for debugging
      catchError(error => {
        console.error('Deposit error:', error); // Log the error
        return throwError(error); // Pass the error up
      })
    );
  }
  

  withdraw(accountNumber: string, amount: number): Observable<any> {
    const withdrawDto = { accountNumber, amount }; // Create DTO
  
    // Get JWT token from local storage
    const token = localStorage.getItem('authToken');
    
    if (!token) {
      console.error('No token found in local storage.');
      return throwError('User is not authenticated.'); // Handle missing token
    }
  
    // Add Authorization header with the token
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`, // Ensure token is sent
      'Content-Type': 'application/json'
    });
  
    // Make the HTTP POST request
    return this.http.post<any>(`${this.apiUrl}/withdraw`, withdrawDto, { headers }).pipe(
        tap(response => {
          console.log('Withdraw response:', response); // Log response for debugging
        }),
        catchError(error => {
          console.error('Withdraw error:', error); // Log the error
          return throwError(error); // Pass the error up for further handling
        })
    );
  }
  

transfer(transferDto: any): Observable<any> {
  // Get JWT token from local storage
  const token = localStorage.getItem('authToken');
  
  // Add Authorization header with the token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`, // Ensure token is sent
    'Content-Type': 'application/json'
  });

  return this.http.post<any>(`${this.apiUrl}/transfer`, transferDto, { headers }).pipe(
    tap(response => console.log('Transfer response:', response)), // Log response for debugging
    catchError(error => {
      console.error('Transfer error:', error); // Log the error
      return throwError(error); // Pass the error up
    })
  );
}


getTransactions(accountNumber: string): Observable<Transaction[]> {
  // Get JWT token from local storage
  const token = localStorage.getItem('authToken');
  
  // Add Authorization header with the token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`, // Ensure token is sent
    'Content-Type': 'application/json'
  });

  return this.http.get<Transaction[]>(`${this.apiUrl}/transactions/${accountNumber}`, { headers });
}


getProfile(accountNumber: string): Observable<any> {
  // Get JWT token from local storage
  const token = localStorage.getItem('authToken');
  
  // Add Authorization header with the token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`, // Ensure token is sent
    'Content-Type': 'application/json'
  });

  return this.http.get<any>(`${this.apiUrl}/profile/${accountNumber}`, { headers });
}


getSecurityQuestion(username: string): Observable<any> {
  return this.http.get<any>(`/api/accounts/security-question/${username}`);
}

verifySecurityAnswer(username: string, answer: string): Observable<any> {
  return this.http.post<any>('/api/accounts/verify-answer', { username, answer });
}

updatePassword(username: string, newPassword: string): Observable<any> {
  return this.http.post<any>('/api/accounts/update-password', { username, newPassword });
}

// Method to send a money request
requestMoney(requestData: any): Observable<any> {
  // Get JWT token from local storage
  const token = localStorage.getItem('authToken');

  // Add Authorization header with the token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`, // Ensure token is sent
    'Content-Type': 'application/json'
  });

  return this.http.post(`${this.apiUrl}/create-request`, requestData, { headers });
}


getPendingRequests(accountNumber: string): Observable<any[]> {
  // Retrieve JWT token from local storage
  const token = localStorage.getItem('authToken');

  // Add Authorization header with the JWT token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`, // JWT token
    'Content-Type': 'application/json'
  });

  return this.http.get<any[]>(`${this.apiUrl}/pending-requests/${accountNumber}`, { headers });
}


// Accept a money request
acceptRequest(requestId: number): Observable<any> {
  // Retrieve JWT token from local storage
  const token = localStorage.getItem('authToken');

  // Add Authorization header with the JWT token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`, // JWT token
    'Content-Type': 'application/json'
  });

  return this.http.post(`${this.apiUrl}/accept-request/${requestId}`, {}, { headers });
}


rejectRequest(requestId: number): Observable<any> {
  // Retrieve JWT token from local storage
  const token = localStorage.getItem('authToken');

  // Add Authorization header with the JWT token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`, // JWT token
    'Content-Type': 'application/json'
  });

  return this.http.post(`${this.apiUrl}/reject/${requestId}`, {}, { headers });
}

getVirtualCards(accountId: number): Observable<VirtualCard[]> {
  const token = localStorage.getItem('authToken'); // Retrieve the JWT token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  });

  return this.http.get<VirtualCard[]>(`${this.apiUrl}/debit-card/${accountId}`, { headers }).pipe(
    tap(response => console.log('Fetched virtual cards:', response)),
    catchError(error => {
      console.error('Error fetching virtual cards:', error);
      return throwError(error); // Pass the error up
    })
  );
}



}
