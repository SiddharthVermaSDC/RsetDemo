import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  isUserLoggedIn = new BehaviorSubject<boolean>(false); 

  private apiurl = 'https://localhost:7025/';

  constructor(private http: HttpClient,private router: Router) { 
    const token = localStorage.getItem('authToken');
    if (token) {
      this.isUserLoggedIn.next(true);
    }
  }

  register(registerData: any): Observable<any> {
    return this.http.post(`${this.apiurl}register`, registerData);
  }

  // Perform login by calling the backend API
  login(username: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiurl}login`, { username, password }).pipe(
      map(response => {
        if (response && response.token) {
          localStorage.setItem('authToken', response.token);
          localStorage.setItem('accountNumber', response.accountNumber);
          localStorage.setItem('accountId',response.accountId);
          this.isUserLoggedIn.next(true); // Set logged in state to true
        }
        return response;
      })
    );
  }

  logout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('accountNumber');
    this.isUserLoggedIn.next(false); // Set logged in state to false
    this.router.navigate(['/logout']);
  }

  // Expose the logged-in state as an observable
  getLoginStatus(): Observable<boolean> {
    return this.isUserLoggedIn.asObservable();
  }

}
