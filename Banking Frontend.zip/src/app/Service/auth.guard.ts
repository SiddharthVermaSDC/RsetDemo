import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { first, map } from 'rxjs';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const authService = inject(AuthService);

  return authService.isUserLoggedIn.pipe(
    first(),
    map((loginStatus: boolean)=>{
      if(!loginStatus){
        router.navigate(['login']);
        return false;
      }
      return true;
    })
  );
};
