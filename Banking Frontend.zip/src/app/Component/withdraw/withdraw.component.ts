import { Component } from '@angular/core';
import { AccountService } from '../../Service/account.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrl: './withdraw.component.css'
})
export class WithdrawComponent {
  withdrawAmount: number;
  accountNumber: string;
  message: string;
  balance: number;

  constructor(private accountService: AccountService, private router:Router,private toastr: ToastrService) {
    this.accountNumber = localStorage.getItem('accountNumber'); 
  }

  withdraw(): void {
    this.accountService.withdraw(this.accountNumber, this.withdrawAmount).subscribe(
        response => {
            this.getBalance(); // Refresh balance
            this.withdrawAmount = null; // Clear input
            this.toastr.success(response.message); // Display the response message from the API
            this.router.navigate(['/dashboard']);
        },
        error => {
            console.error('Withdraw error:', error);
            alert('Withdrawal failed'); // Generic error message
        }
    );
}


getBalance(): void {
  this.accountService.getBalance(this.accountNumber).subscribe(
    response => {
      this.balance = response.balance;
    },
    error => {
      console.error('Error fetching balance:', error);
    }
  );
}

}