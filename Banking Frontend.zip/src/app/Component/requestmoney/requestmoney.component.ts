import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../Service/account.service';

@Component({
  selector: 'app-requestmoney',
  templateUrl: './requestmoney.component.html',
  styleUrl: './requestmoney.component.css'
})
export class RequestmoneyComponent implements OnInit {
  fromAccountNumber: string = ''; // The account number of the logged-in user (fetch from localStorage)
  toAccountNumber: string = '';   // The account number of the recipient
  amount: number = 0;             // Amount to request
  description: string = '';        // Optional description for the request
  message: string = '';            // Success or error message
  reenterToAccountNumber: string = '';

  constructor(private accountService: AccountService) {}

  ngOnInit(): void {
    this.fromAccountNumber = localStorage.getItem('accountNumber') || '';
  }

  // Method to submit the request money form
  requestMoney(): void {
    if (this.fromAccountNumber && this.toAccountNumber && this.amount > 0) {
      const requestData = {
        fromAccountNumber: this.fromAccountNumber,
        toAccountNumber: this.toAccountNumber,
        amount: this.amount,
        description: this.description,
      };

      this.accountService.requestMoney(requestData).subscribe(
        (response) => {
          this.message = 'Money request sent successfully!';
          this.clearForm();
          this.reenterToAccountNumber=null;
        },
        (error) => {
          this.message = 'Error sending money request.';
        }
      );
    } else {
      this.message = 'Please fill in all fields correctly.';
    }
  }

  // Method to clear the form fields after submission
  clearForm(): void {
    this.toAccountNumber = '';
    this.amount = 0;
    this.description = '';
  }
}