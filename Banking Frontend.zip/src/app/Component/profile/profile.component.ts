import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../Service/account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
  profileData: any = null;
  accountNumber: string | null = '';

  constructor(private accountService: AccountService, private router:Router) {}

  ngOnInit(): void {
    // Get account number from localStorage
    this.accountNumber = localStorage.getItem('accountNumber');

    if (this.accountNumber) {
      // Fetch the profile data using AccountService
      this.accountService.getProfile(this.accountNumber).subscribe(
        (data) => {
          this.profileData = data;
        },
        (error) => {
          console.error('Error fetching profile data:', error);
        }
      );
    }
  }

  goBackToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}