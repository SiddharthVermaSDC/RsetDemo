import { Component } from '@angular/core';
import { AccountService } from '../../Service/account.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrl: './deposit.component.css'
})
export class DepositComponent {
  depositAmount: number;
  accountNumber: string;
  message: string;

  constructor(private accountService: AccountService,private router: Router,private toastr: ToastrService) {
    this.accountNumber = localStorage.getItem('accountNumber'); // Fetch from local storage
  }

  deposit(): void {
    this.accountService.deposit(this.accountNumber, this.depositAmount).subscribe(
      response => {
        this.message = response.message; // Display success message
        this.depositAmount = null; // Clear input
        this.toastr.success(response.message);
        this.router.navigate(['/dashboard']);
      },
      error => {
        console.error('Deposit error:', error);
        this.message = 'Deposit failed'; // Display error message
      }
    );
  }
}