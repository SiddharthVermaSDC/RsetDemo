import { Component, OnInit } from '@angular/core';
import { AccountService, Transaction, VirtualCard } from '../../Service/account.service';
import { HttpClient } from '@angular/common/http';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'] // Corrected here from 'styleUrl'
})
export class DashboardComponent implements OnInit {
  accountNumber: string;
  balance: number;
  transactions: Transaction[] = [];
  recentTransactions: Transaction[] = [];
  virtualCards: VirtualCard[] = [];
  showCardDetails: boolean[] = [];

  constructor(private http: HttpClient, private accountService: AccountService) {
    this.accountNumber = localStorage.getItem('accountNumber'); // Fetch from local storage
    Chart.register(...registerables);
  }

  ngOnInit(): void {
    this.getBalance();
    const accountId = Number(localStorage.getItem('accountId'));
    
    if (this.accountNumber) {
      this.accountService.getTransactions(this.accountNumber).subscribe((data) => {
        // Sort transactions by date in descending order
        this.transactions = data.sort((a, b) => {
          return new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime();
        });
        this.recentTransactions = this.transactions.slice(0, 6);
        this.initializeChart(); 
      });
    }

    if (accountId) {
      this.accountService.getVirtualCards(accountId).subscribe(
        (cards) => {
          this.virtualCards = cards;
          this.showCardDetails = new Array(cards.length).fill(false); // Initialize the array to manage card visibility
        },
        (error) => {
          if (error.status === 404) {
            console.warn('No virtual cards found for this account.');
            this.virtualCards = [];
            this.showCardDetails = []; // Reset card detail visibility
          } else {
            console.error('Error fetching virtual cards:', error);
          }
        }
      );
    }
  }

  getBalance(): void {
    this.accountService.getBalance(this.accountNumber).subscribe(response => {
      this.balance = response.balance;
    }, error => {
      console.error('Error fetching balance:', error);
    });
  }

  toggleCardDetails(index: number): void {
    this.showCardDetails[index] = !this.showCardDetails[index];
  }

  getMaskedCardNumber(cardNumber: string, showDetails: boolean): string {
    return showDetails ? cardNumber : cardNumber.replace(/\d(?=\d{4})/g, '*'); // Mask all but the last 4 digits
  }

  // Method to format card number by adding spaces every 4 digits
formatCardNumber(cardNumber: string): string {
  return cardNumber.replace(/(.{4})/g, '$1 ').trim(); // Adds space after every 4 digits
}

// Method to format expiry date to show MM/YY
formatExpiryDate(expiryDate: string | Date): string {
  const date = typeof expiryDate === 'string' ? new Date(expiryDate) : expiryDate;
  const month = date.getMonth() + 1; // Get the month (0-based index)
  const year = date.getFullYear().toString().slice(-2); // Get last two digits of the year
  return `${month.toString().padStart(2, '0')}/${year}`; // Format as MM/YY
}


  initializeChart(): void {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
  
    // Aggregate credited and debited amounts by date
    const dailyTotals: { [date: string]: { credited: number; debited: number } } = {};
  
    this.transactions.forEach(t => {
      const transactionDate = new Date(t.transactionDate);
      
      // Only include transactions from the current month
      if (transactionDate.getMonth() === currentMonth && transactionDate.getFullYear() === currentYear) {
        const dateKey = transactionDate.toLocaleDateString(); // Format date as a string (e.g., "MM/DD/YYYY")
        
        // Initialize if not exists
        if (!dailyTotals[dateKey]) {
          dailyTotals[dateKey] = { credited: 0, debited: 0 };
        }
  
        // Aggregate amounts based on transaction type
        if (t.transactionType === 'Credited') {
          dailyTotals[dateKey].credited += t.amount;
        } else if (t.transactionType === 'Debited') {
          dailyTotals[dateKey].debited += t.amount;
        }
      }
    });
  
    // Prepare data for the chart
    const chartLabels = Object.keys(dailyTotals);
    const creditedData = chartLabels.map(date => dailyTotals[date].credited);
    const debitedData = chartLabels.map(date => dailyTotals[date].debited);
  
    const ctx = document.getElementById('transactionChart') as HTMLCanvasElement;
  
    new Chart(ctx, {
      type: 'bar', // You can choose 'bar', 'doughnut', or 'pie' as needed
      data: {
        labels: chartLabels,
        datasets: [
          {
            label: 'Total Credited',
            data: creditedData,
            backgroundColor: 'rgba(54, 162, 235, 0.7)', // Light blue fill
          },
          {
            label: 'Total Debited',
            data: debitedData,
            backgroundColor: 'rgba(255, 99, 132, 0.7)', // Light red fill
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Amount (₹)',
            }
          }
        }
      }
    });
  }
}
