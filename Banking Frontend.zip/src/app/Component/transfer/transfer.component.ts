import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../Service/account.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrl: './transfer.component.css'
})
export class TransferComponent implements OnInit {
  accountNumber: string;
  toAccountNumber: string;
  amount: number;
  reenterToAccountNumber: string = '';

  constructor(private accountService: AccountService, private router : Router,private toastr: ToastrService) {
    this.accountNumber = localStorage.getItem('accountNumber'); // Fetch from local storage
  }

  ngOnInit(): void {
    // Any initialization logic can go here
  }

  transfer(): void {
    const transferDto = {
      fromAccountNumber: this.accountNumber,
      toAccountNumber: this.toAccountNumber,
      amount: this.amount
    };

    this.accountService.transfer(transferDto).subscribe(
      response => {
        this.toastr.success(response.message); // Display the response message from the API
        this.toAccountNumber = null; // Clear input
        this.amount = null; // Clear input
        this.reenterToAccountNumber=null;
        this.router.navigate(['/dashboard']);
      },
      error => {
        console.error('Transfer error:', error);
        this.toastr.error('Transfer failed', 'Error'); // Generic error message
      }
    );
  }
}