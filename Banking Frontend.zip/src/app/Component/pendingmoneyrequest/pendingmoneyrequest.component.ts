import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../Service/account.service';

@Component({
  selector: 'app-pendingmoneyrequest',
  templateUrl: './pendingmoneyrequest.component.html',
  styleUrl: './pendingmoneyrequest.component.css'
})
export class PendingmoneyrequestComponent implements OnInit {
  accountNumber: string = ''; // Fetch the logged-in user's account number (from localStorage)
  pendingRequests: any[] = [];
  message: string = '';

  constructor(private accountService: AccountService) {}

  ngOnInit(): void {
    this.accountNumber = localStorage.getItem('accountNumber') || ''; //fetching account number from local storage
    this.loadPendingRequests();
  }

  // Load pending requests for this account
  loadPendingRequests(): void {
    if (this.accountNumber) {
      this.accountService.getPendingRequests(this.accountNumber).subscribe(
        (requests) => {
          this.pendingRequests = requests;
        },
        (error) => {
          console.log('Error loading pending requests', error);
        }
      );
    }
  }

  // Accept money request
  acceptRequest(requestId: number): void {
    this.accountService.acceptRequest(requestId).subscribe(
      (response) => {
        this.message = 'Request accepted successfully.';
        this.loadPendingRequests(); // Reload the requests after accepting
      },
      (error) => {
        this.message = 'Error accepting the request.';
      }
    );
  }

  rejectRequest(requestId: number): void {
    this.accountService.rejectRequest(requestId).subscribe(
      (response) => {
        this.message = 'Request rejected successfully.';
        this.loadPendingRequests(); // Reload the requests after rejecting
      },
      (error) => {
        this.message = 'Error rejecting the request.';
      }
    );
  }
}