import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingmoneyrequestComponent } from './pendingmoneyrequest.component';

describe('PendingmoneyrequestComponent', () => {
  let component: PendingmoneyrequestComponent;
  let fixture: ComponentFixture<PendingmoneyrequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PendingmoneyrequestComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingmoneyrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
