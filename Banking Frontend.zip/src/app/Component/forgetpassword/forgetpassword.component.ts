import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
  forgetPasswordForm: FormGroup; // Reactive form group
  securityQuestion: string = '';
  isAnswerValid: boolean = false;
  message: string = '';
  success: boolean = false;
  private apiUrl = 'https://localhost:7025'; 

  constructor(private http: HttpClient, private fb: FormBuilder) {
    // Initialize the FormGroup with validators
    this.forgetPasswordForm = this.fb.group({
      username: ['', Validators.required],
      securityAnswer: ['', Validators.required],
      newPassword: ['', Validators.required]
    });
  }

  ngOnInit() {}

  getSecurityQuestion() {
    const username = this.forgetPasswordForm.get('username')?.value; // Get username from form
    this.http.get<{ success: boolean; question: string }>(`${this.apiUrl}/security-question/${username}`)
      .subscribe(
        response => {
          if (response.success) {
            this.securityQuestion = response.question;
            this.message = '';
          } else {
            this.message = 'User not found.';
            this.success = false;
          }
        },
        error => {
          this.message = 'Error retrieving security question.';
          this.success = false;
        }
      );
  }

  validateSecurityAnswer() {
    return this.http.post<{ success: boolean }>(`${this.apiUrl}/validate-security-answer`, {
      Username: this.forgetPasswordForm.get('username')?.value,
      Answer: this.forgetPasswordForm.get('securityAnswer')?.value
    });
  }

  onSubmit() {
    this.validateSecurityAnswer().subscribe(
      response => {
        if (response.success) {
          this.isAnswerValid = true;
          this.message = 'Security answer validated. Please enter a new password.';
          this.success = true;
        } else {
          this.message = 'Invalid security answer.';
          this.success = false;
        }
      },
      error => {
        this.message = 'Error validating security answer.';
        this.success = false;
      }
    );
  }

  updatePassword() {
    if (!this.isAnswerValid) {
      this.message = 'Please validate your security answer first.';
      return;
    }

    if (this.forgetPasswordForm.invalid) { // Check if form is valid
      this.message = 'Please fill in all required fields.';
      return;
    }

    this.http.post<{ success: boolean; message: string }>(`${this.apiUrl}/update-password`, {
      Username: this.forgetPasswordForm.get('username')?.value,
      NewPassword: this.forgetPasswordForm.get('newPassword')?.value
    }).subscribe(
      response => {
        this.message = response.message;
        this.success = response.success;

        // Reset form fields if successful
        if (response.success) {
          this.forgetPasswordForm.reset(); // Reset the FormGroup
          this.isAnswerValid = false;
          this.securityQuestion = ''; // Clear the security question
        }
      },
      error => {
        this.message = 'Error updating password.';
        this.success = false;
      }
    );
  }
}
