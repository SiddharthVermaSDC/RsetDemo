import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../../Service/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {
  isUserLoggedIn: Observable<boolean>;

  constructor(private authService: AuthService) { }

  time = new Observable<string>((observer) => {
    setInterval(()=>observer.next(new Date().toString()),1000);
     });

  ngOnInit() {
    // Subscribe to login status
    this.isUserLoggedIn = this.authService.getLoginStatus();
  }
}
