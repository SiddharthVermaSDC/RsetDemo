import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../Service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm: FormGroup;
  submitted = false;
  errorMessage = '';
  captchaResponse: string | null = null;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,  // Inject AuthService
    private router: Router  // For navigation after login
  ) {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      recaptcha: ['', Validators.required]
    });
  }

  // Getter for easy access to form controls
  get f() {
    return this.loginForm.controls;
  }

  // Handle CAPTCHA response
  resolved(captchaResponse: string): void {
    this.captchaResponse = captchaResponse;  // Capture the CAPTCHA response token
    this.loginForm.controls['recaptcha'].setValue(captchaResponse);  // Set the value in the form control
  }
  

  onSubmit() {
    this.submitted = true;

    // Stop if the form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    const { username, password } = this.loginForm.value;

    // Call AuthService login method
    this.authService.login(username, password).subscribe(
      (response) => {
        // Handle successful login (redirect to dashboard or home page)
        this.router.navigate(['/dashboard']);  //navigation after login
      },
      (error) => {
        // Handle error (invalid credentials, server error, etc.)
        this.errorMessage = 'Invalid username or password';
      }
    );
  }
}