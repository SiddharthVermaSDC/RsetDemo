import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { dateOfBirthValidator } from '../../Validators/dob.validator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  currentTabIndex: number = 0;
  selectedFile: File | null = null;
  fileError: string = '';  // To store any file-related error messages

  allowedFileTypes = ['image/png', 'image/jpeg', 'application/pdf'];  // Allowed MIME types
  maxFileSize = 5 * 1024 * 1024;  // 5 MB

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router) {
    
  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.maxLength(50)]],
      lastName: ['', [Validators.required, Validators.maxLength(50)]],
      dateOfBirth: ['', [Validators.required, dateOfBirthValidator()]],
      gender: ['', [Validators.required, Validators.maxLength(10)]],
      houseNumber: ['', Validators.maxLength(20)],
      street: ['', Validators.maxLength(100)],
      city: ['', Validators.maxLength(50)],
      state: ['', Validators.maxLength(50)],
      country: ['', Validators.maxLength(50)],
      pinCode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
      phoneNumber: ['', [Validators.required,Validators.pattern('^[6-9]\\d{9}$')]],
      email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]],
      idCardNumber: ['',[Validators.required, Validators.pattern('^\\d{12}$')]],
      accountType: ['', Validators.required],
      category: ['', Validators.required],
      attachmentType: ['', Validators.required],
      password: ['', [Validators.required, Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$')]],
      securityQuestion: ['', [Validators.required, Validators.maxLength(100)]],
      securityAnswer: ['', Validators.required],
      username: ['', [Validators.required, Validators.maxLength(50)]],
      jointAccountHolderName: ['', Validators.maxLength(100)],
      acceptTerms: [false, Validators.requiredTrue]
    });
  }

  // Convenience getter for form controls
  get f() {
    return this.registerForm.controls;
  }

  // Method to handle file changes
  onFileChange(event: any) {
    const file = event.target.files[0];
    this.fileError = '';  // Reset error messages

    if (file) {
      // Check file type
      if (!this.allowedFileTypes.includes(file.type)) {
        this.fileError = 'Invalid file type. Only PNG, JPG, and PDF files are allowed.';
        this.selectedFile = null;
        return;
      }

      // Check file size
      if (file.size > this.maxFileSize) {
        this.fileError = 'File size exceeds the 5 MB limit.';
        this.selectedFile = null;
        return;
      }

      // If file passes all checks
      this.selectedFile = file;
    }
  }

  onSubmit() {
    this.submitted = true;

    // Ensure form is valid and file is selected
    if (this.registerForm.invalid || !this.selectedFile || this.fileError) {
      return;
    }

    const formData = new FormData();

    // Append form data
    Object.keys(this.registerForm.controls).forEach(key => {
      formData.append(key, this.registerForm.get(key)?.value);
    });

    // Append file to form data
    if (this.selectedFile) {
      formData.append('file', this.selectedFile);
    }

    this.http.post('https://localhost:7025/register', formData).subscribe(
      response => {
        alert('Registration successful!');
        this.router.navigate(['/login']);  // Redirect to login or another page
      },
      error => {
        console.error('Registration failed', error);
      }
    );
  }

  private updateTabVisibility() {
    const tabs = document.querySelectorAll('.tab-pane');
    tabs.forEach((tab, index) => {
      tab.classList.remove('show', 'active');
      if (index === this.currentTabIndex) {
        tab.classList.add('show', 'active');
      }
    });
  }
}
