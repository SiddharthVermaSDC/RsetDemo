import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './Component/register/register.component';
import { DashboardComponent } from './Component/dashboard/dashboard.component';
import { LogoutComponent } from './Component/logout/logout.component';
import { DepositComponent } from './Component/deposit/deposit.component';
import { WithdrawComponent } from './Component/withdraw/withdraw.component';
import { TransferComponent } from './Component/transfer/transfer.component';
import { TransactionComponent } from './Component/transaction/transaction.component';
import { authGuard } from './Service/auth.guard';
import { ProfileComponent } from './Component/profile/profile.component';
import { PagenotfoundComponent } from './Component/pagenotfound/pagenotfound.component';
import { ForgetpasswordComponent } from './Component/forgetpassword/forgetpassword.component';
import { RequestmoneyComponent } from './Component/requestmoney/requestmoney.component';
import { PendingmoneyrequestComponent } from './Component/pendingmoneyrequest/pendingmoneyrequest.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'deposit', component: DepositComponent,canActivate:[authGuard] },
  { path: 'withdraw', component: WithdrawComponent,canActivate:[authGuard] },
  { path: 'transfer', component: TransferComponent,canActivate:[authGuard] },
  { path: 'transactions', component: TransactionComponent,canActivate:[authGuard] },
  { path: 'profile', component: ProfileComponent },
  {path: 'dashboard', component: DashboardComponent,canActivate:[authGuard]},
  { path: 'forget-password', component: ForgetpasswordComponent },
  { path: 'request-money', component: RequestmoneyComponent },
  { path: 'pending-requests', component: PendingmoneyrequestComponent },
  {path:'**',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
