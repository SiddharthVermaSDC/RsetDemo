import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RecaptchaModule } from 'ng-recaptcha';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './Component/register/register.component';
import { HeaderComponent } from './Component/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { DashboardComponent } from './Component/dashboard/dashboard.component';
import { LogoutComponent } from './Component/logout/logout.component';
import { DepositComponent } from './Component/deposit/deposit.component';
import { WithdrawComponent } from './Component/withdraw/withdraw.component';
import { TransferComponent } from './Component/transfer/transfer.component';
// import { TratransactionComponent } from './Component/tratransaction/tratransaction.component';
import { TransactionComponent } from './Component/transaction/transaction.component';
import { ProfileComponent } from './Component/profile/profile.component';
import { FooterComponent } from './Component/footer/footer.component';
import { PagenotfoundComponent } from './Component/pagenotfound/pagenotfound.component';
import { ForgetpasswordComponent } from './Component/forgetpassword/forgetpassword.component';
import { RequestmoneyComponent } from './Component/requestmoney/requestmoney.component';
import { PendingmoneyrequestComponent } from './Component/pendingmoneyrequest/pendingmoneyrequest.component';
//import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    DashboardComponent,
    LogoutComponent,
    DepositComponent,
    WithdrawComponent,
    TransferComponent, 
    TransactionComponent, ProfileComponent, FooterComponent, PagenotfoundComponent, ForgetpasswordComponent, RequestmoneyComponent, PendingmoneyrequestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RecaptchaModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      positionClass: 'toast-top-right', // Ensures it appears in the top-right corner
      preventDuplicates: true,
      timeOut: 3000, // Adjust the duration as needed
      progressBar: true
    }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
